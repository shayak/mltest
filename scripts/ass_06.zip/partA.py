import myUtilities

name = myUtilities.getName()
print(f'Hello {name}!')
bday = myUtilities.getBirthdate()
age = myUtilities.age(bday)
print(f'You are {age} years old.')
